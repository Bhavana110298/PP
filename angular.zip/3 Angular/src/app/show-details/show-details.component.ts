import { Component, OnInit } from '@angular/core';
import { BankService } from '../bank.service';
import { Customer } from '../customer';

@Component({
  selector: 'app-show-details',
  templateUrl: './show-details.component.html',
  styleUrls: ['./show-details.component.css']
})
export class ShowDetailsComponent implements OnInit {

  bankService: BankService;
  getDetails: Customer;
  balance:number;
  shown: boolean = true;
  constructor(bankServie: BankService) {
    this.bankService = bankServie;
   }

   showBalance(data:any){
    this.getDetails = this.bankService.showBalance(data);
    this.balance = this.getDetails.balance;
   }

   show(){
     this.shown = !this.shown;
   }

   ngOnInit() {
   }
}
