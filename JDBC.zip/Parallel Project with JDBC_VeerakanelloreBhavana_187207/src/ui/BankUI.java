package ui;

import java.sql.SQLException;
import java.util.Scanner;

import bean.BankTransaction;
import exceptions.*;
import service.BankServiceImpl;
import service.BankService;

public class BankUI {
	static Scanner scan = new Scanner(System.in);
	static BankTransaction transaction = new BankTransaction();
	static BankTransaction transaction1 = new BankTransaction();

	public static void main(String[] args) throws AccountNotFoundException, ClassNotFoundException, SQLException {

		// variables initilization and declarations

		long accNum, accNum1;
		int withdraw_amount, deposit_amount = 0, transfer_amount = 0;
		int pin;
		int amount = 0;
		int balance = 0;
		boolean result = false;
		String cont = "yes";

		BankService service = new BankServiceImpl();

		// To ask choice from users and perform operations
		while (cont.equalsIgnoreCase("yes")) {
			switch (menu()) {

			// to create an account

			case 1:

				System.out.println("Enter name:");
				String name = scan.nextLine();
				name += scan.nextLine();

				String regexUserName = "[A-Za-z\\s]+$";
				while (!name.matches(regexUserName)) {

					System.out.println("Invalid Format");
					System.out.println("Enter name:");
					name = scan.next();
				}

				System.out.println("Enter address: ");
				String add = scan.next();
				add += scan.nextLine();

				while (!add.matches(regexUserName)) {
					System.out.println("Invalid Format");
					System.out.println("Enter address: ");
					add = scan.nextLine();

				}

				System.out.println("Enter phone number:");
				String phone = scan.next();
				String phone_format = ("[6-9][0-9]{9}");

				while (!phone.matches(phone_format)) {
					while (phone.length() < 10 || phone.length() > 10) {

						System.out.println("Phone number should be 0f 10 digits");
						System.out.println("Enter phone number:");
						phone = scan.next();
					}
					System.out.println("Phone number should start from 6");
					System.out.println("Enter phone number:");
					phone = scan.next();
				}

				accNum = Long.parseLong(phone) - 10000;

				System.out.println("Enter Pin:");
				pin = scan.nextInt();

				while (String.valueOf(pin).length() < 4 || String.valueOf(pin).length() > 4) {

					System.out.println("Pin number should be 0f 4 digits");
					System.out.println("Enter Pin:");
					pin = scan.nextInt();
				}

				System.out.println("Enter Balance:");
				int bal = scan.nextInt();

				while (bal < 1000) {
					System.out.println("Minimum Balance should be 1000");
					System.out.println("Enter Balance:");
					bal = scan.nextInt();

				}
				try {
					result = service.createAccount(name, add, accNum, phone, pin, bal);
				} catch (AccountAlreadyExistsException e) {

					System.out.println(e);
					break;
				}

				if (result == true) {
					System.out.println("Account Created Successfully !!!");
					System.out.println("Account Number : " + accNum);

					int trans_id = ((int) Math.random() * 1000 + 1000);
					transaction.setAccNum(accNum);
					transaction.setType("Create");
					transaction.setAmount(bal);
					transaction.setTransaction_id(trans_id);

					service.setTransactions(transaction);

				} else {

					System.out.println("Cannot Create Account");
				}

				break;

			// to show balance in account
			case 2:

				System.out.println("Enter account number:");
				accNum = scan.nextLong();

				try {
					balance = service.showBalance(accNum);
				} catch (AccountNotFoundException e) {
					System.out.println(e);
					break;
				}

				System.out.println("Balance :" + balance);

				break;

			// to deposit amount into account

			case 3:

				System.out.println("Enter account no:");
				accNum = scan.nextLong();

				System.out.println("Enter amount to be deposited:");
				deposit_amount = scan.nextInt();

				try {
					amount = service.deposit(accNum, deposit_amount);

					balance = service.showBalance(accNum);
				}

				catch (AccountNotFoundException e) {

					System.out.println(e);
					break;
				}

				System.out.println("Amount Deposited : " + deposit_amount);
				System.out.println("Updated Balance : " + balance);

				int trans_id = ((int) Math.random() * 1000 + 1000);
				transaction.setAccNum(accNum);
				transaction.setType("Deposit");
				transaction.setAmount(deposit_amount);
				transaction.setTransaction_id(trans_id);
				service.setTransactions(transaction);

				break;

			// to withdraw amount 

			case 4:

				System.out.println("Enter account no:");
				accNum = scan.nextLong();

				System.out.println("Enter amount to withdraw:");
				withdraw_amount = scan.nextInt();

				try {
					amount = service.withDraw(accNum, withdraw_amount);
					result = service.validateBalance(accNum, withdraw_amount);
					balance = service.showBalance(accNum);

				} catch (AccountNotFoundException e) {

					System.out.println(e);
					break;

				} catch (LowBalanceException e) {

					System.out.println(e);
					break;
				}

				System.out.println("Amount Withdrawn : " + withdraw_amount);
				System.out.println("Updated Balance : " + balance);

				int trans_id1 = ((int) Math.random() * 1000 + 1000);
				transaction.setAccNum(accNum);
				transaction.setType("Withdraw");
				transaction.setAmount(withdraw_amount);
				transaction.setTransaction_id(trans_id1);
				service.setTransactions(transaction);

				break;

			// to transfer fund

			case 5:

				int senders_balance = 0;
				int recievers_balance = 0;

				System.out.println("Enter account number:");
				accNum = scan.nextLong();

				System.out.println("Enter account to which you want to transfer fund:");
				accNum1 = scan.nextLong();

				System.out.println("Enter amount to transfer:");
				transfer_amount = scan.nextInt();

				try {
					result = service.validateBalance(accNum, transfer_amount);
					result = service.transferFund(accNum, accNum1, transfer_amount);

					senders_balance = service.showBalance(accNum);
					recievers_balance = service.showBalance(accNum1);

				} catch (AccountNotFoundException e) {

					System.out.println(e);
					break;
				} catch (LowBalanceException e) {
					System.out.println(e);
					break;
				}

				System.out.println("Amount transferred Successfully");
				System.out.println("Updated balance for Account " + accNum + " : " + senders_balance);
				System.out.println("Updated balance for Account " + accNum1 + " : " + recievers_balance);

				int trans_id_1 = ((int) Math.random() * 1000 + 1000);
				transaction.setAccNum(accNum);
				transaction.setType("Transfer");
				transaction.setAmount(transfer_amount);
				transaction.setTransaction_id(trans_id_1);
				service.setTransactions(transaction);

				int trans_id_2 = ((int) Math.random() * 1000 + 1000);
				transaction1.setAccNum(accNum1);
				transaction1.setType("Transfer");
				transaction1.setAmount(transfer_amount);
				transaction1.setTransaction_id(trans_id_2);
				service.setTransactions(transaction1);

				break;

			// to show transactions
			case 6:

				System.out.println("Enter account number");
				accNum = scan.nextLong();
				transaction = service.getTransactions(accNum);
				if (transaction == null) {
					throw new AccountNotFoundException();
				} else {
					System.out.println("--------Transactions----------");
					System.out.println("Transaction type : " + transaction.getType());
					System.out.println("Transaction Id : " + transaction.getTransaction_id());
					System.out.println("Transaction Account : " + transaction.getAccNum());
					System.out.println("Transaction Amount : " + transaction.getAmount());
				}
				break;
				// to exit
			case 7:System.out.println("Thankyou");
				System.exit(0);
				cont = "no";
				break;
			default:
				System.out.println("Please Enter choice between 1 - 7 ");
				menu();

			}
		}

	}

	// to display menu
	public static int menu() {

		System.out.println("------------Welcome to XYZ Bank----------");
		System.out.println("1.Create Account");
		System.out.println("2.Show Balance");
		System.out.println("3.Deposit");
		System.out.println("4.Withdraw");
		System.out.println("5.Transer Fund");
		System.out.println("6.Print Transcations");
		System.out.println("7.Exit");

		System.out.println("Enter Choice");
		int choice = scan.nextInt();
		String s = Integer.toString(choice);
		String pattern = ("[0-7]{1}");
		while (!s.matches(pattern)) {
			System.out.println("Invalid Choice");
			System.out.println("Enter Choice");
			choice = scan.nextInt();
		}

		return choice;
	}

}
