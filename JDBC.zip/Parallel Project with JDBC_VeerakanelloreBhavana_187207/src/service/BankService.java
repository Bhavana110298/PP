package service;

import java.sql.SQLException;

import bean.BankTransaction;
import exceptions.*;

public interface BankService {

	public boolean createAccount(String name, String address, long accNum, String phone, int pin, int balance)
			throws AccountAlreadyExistsException, ClassNotFoundException, SQLException;

	public int showBalance(long accNum) throws AccountNotFoundException, ClassNotFoundException, SQLException;

	public int deposit(long accNum, int deposit_amount)
			throws AccountNotFoundException, ClassNotFoundException, SQLException;

	public int withDraw(long accNum, int withdraw_amount)
			throws AccountNotFoundException, LowBalanceException, ClassNotFoundException, SQLException;

	public boolean transferFund(long accNum, long accNum1, int transfer_amount)
			throws AccountNotFoundException, LowBalanceException, ClassNotFoundException, SQLException;

	public boolean validateBalance(long accNum, int amount)
			throws LowBalanceException, ClassNotFoundException, SQLException, AccountNotFoundException;

	public String setTrans(long accNum) throws AccountNotFoundException, ClassNotFoundException, SQLException;

	public void setTransactions(BankTransaction transaction) throws ClassNotFoundException, SQLException;

	public BankTransaction getTransactions(long accNum) throws ClassNotFoundException, SQLException;

}
