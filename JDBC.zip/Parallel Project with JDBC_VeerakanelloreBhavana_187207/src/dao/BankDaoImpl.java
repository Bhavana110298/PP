package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import bean.BankBean;
import bean.BankTransaction;

public class BankDaoImpl implements BankDao {

	Connection conn = null;
	PreparedStatement ps = null;
	ResultSet rs = null;
	BankBean bank = new BankBean();

	@Override
	public boolean checkAccount(long accNum) throws ClassNotFoundException, SQLException {

		boolean result = false;

		String query = "select * from bank where accNo = ?";
		conn = BankDB.getConnection();
		ps = conn.prepareStatement(query);
		ps.setLong(1, accNum);
		rs = ps.executeQuery();

		if (rs.next()) {
			result = false;
		} else {
			result = true;
		}
		return result;
	}

	@Override
	public void insertData(long accNum, BankBean bank) throws ClassNotFoundException, SQLException {

		conn = BankDB.getConnection();
		ps = conn.prepareStatement("insert into bank values (?,?,?,?,?,?)");

		ps.setString(1, bank.getName());
		ps.setLong(2, bank.getAccNo());
		ps.setLong(3, bank.getPin());
		ps.setString(4, bank.getAddress());
		ps.setString(5, bank.getPhone());
		ps.setInt(6, bank.getBalance());

		int r = ps.executeUpdate();

		if (r == 0) {
			System.out.println("Not inserted");
		} else {
			System.out.println("Value inserted");
		}
	}

	@Override
	public void updateData(BankBean bank) throws ClassNotFoundException, SQLException {

		conn = BankDB.getConnection();
		ps = conn.prepareStatement("update bank set balance = ? where accNo = ?");
		ps.setInt(1, bank.getBalance());
		ps.setLong(2, bank.getAccNo());

		int r = ps.executeUpdate();

		if (r == 0) {
			System.out.println("Cannot update");
		} else {
			System.out.println("Updated");
		}
	}

	@Override
	public BankBean getAccountDetails(long accNum) throws ClassNotFoundException, SQLException {
		boolean result = false;

		String query = "select * from bank where accNo = ?";
		conn = BankDB.getConnection();
		ps = conn.prepareStatement(query);
		ps.setLong(1, accNum);
		rs = ps.executeQuery();

		if (rs.next()) {
			bank.setName(rs.getString(1));
			bank.setAccNo(rs.getLong(2));
			bank.setPin(rs.getInt(3));
			bank.setAddress(rs.getString(4));
			bank.setPhone(rs.getString(5));
			bank.setBalance(rs.getInt(6));
		} else {
			bank = null;
		}
		return bank;
	}

	@Override
	public void setTransactions(BankTransaction transaction) throws ClassNotFoundException, SQLException {

		String query = "insert into transactions values (?,?,?,?)";
		conn = BankDB.getConnection();
		ps = conn.prepareStatement(query);
		ps.setString(1, transaction.getType());
		ps.setLong(2, transaction.getAccNum());
		ps.setInt(3, transaction.getAmount());
		ps.setInt(4, transaction.getTransaction_id());

		int res = ps.executeUpdate();

		if (res == 0) {
			System.out.println("Cannot insert");
		} else {
			System.out.println("Updated ");
		}

	}

	@Override
	public BankTransaction getTransactions(long accNum) throws ClassNotFoundException, SQLException {

		BankTransaction transaction = new BankTransaction();
		String query = "select * from transactions where accnum = ?";
		conn = BankDB.getConnection();
		ps = conn.prepareStatement(query);
		ps.setLong(1, accNum);

		rs = ps.executeQuery();

		if (rs.next()) {
			transaction.setType(rs.getString(1));
			transaction.setAccNum(rs.getLong(2));
			transaction.setAmount(rs.getInt(3));
			transaction.setTransaction_id(rs.getInt(4));
		}
		return transaction;
	}

}
