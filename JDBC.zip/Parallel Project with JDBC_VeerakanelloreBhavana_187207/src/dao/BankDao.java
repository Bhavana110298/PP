package dao;

import java.sql.SQLException;

import bean.BankBean;
import bean.BankTransaction;

public interface BankDao {



	public void insertData(long accNum, BankBean bank) throws ClassNotFoundException, SQLException;
	
	public void updateData(BankBean bean) throws ClassNotFoundException, SQLException;

	public boolean checkAccount(long accNum) throws ClassNotFoundException, SQLException;

	public BankBean getAccountDetails(long accNum) throws ClassNotFoundException, SQLException;

	public void setTransactions(BankTransaction transaction) throws ClassNotFoundException, SQLException;

	public BankTransaction getTransactions(long accNum) throws ClassNotFoundException, SQLException;

}
