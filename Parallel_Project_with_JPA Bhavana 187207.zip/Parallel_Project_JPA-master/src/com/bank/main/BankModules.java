package com.bank.main;

import java.util.Scanner;

import com.bank.entity.BankDetails;
import com.bank.entity.TransactionDetails;
import com.bank.service.BankService;
import com.bank.service.Validator;

public class BankModules {
	
	Scanner scan = new Scanner(System.in);
	BankService serv;
	BankDetails bankde;
	Validator vali;
	TransactionDetails transaction1;
	TransactionDetails transaction2 = new TransactionDetails();

	//method to create account
	public void createAccount() throws InvalidException {
		serv = new BankService();
		bankde = new BankDetails();
		vali = new Validator();
		System.out.print("Enter the Account Holder Name: ");
		String name = scan.next();
		if(vali.isNameValid(name)) {
			bankde.setName(name);
			System.out.print("Enter the Initial Amount: ");
			int amount = scan.nextInt();
			if(vali.isBalanceValid(amount)) {
				bankde.setAccBalance(amount);
				System.out.print("Enter the Mobile Number: ");
				String mobileNo = scan.next();
				bankde.setMobileno(mobileNo);
				bankde.setAccNo();
				serv.createAccount(bankde);
				System.out.println("Account Created Successfully!!");
				int id = bankde.getAccNo();
				serv.getAccountById(id);
				System.out.println("Your Account Number is: " + bankde.getAccNo());
			}
			else {
				throw new InvalidException("Enter Valid Amount");
			}
		}
		else {
			throw new InvalidException("Enter Valid Name");
		}
	}
	
	//method to show balance 
	public void showBalance() throws InvalidException {
		serv = new BankService();
		bankde = new BankDetails();
		vali = new Validator();
		System.out.print("Enter your Account Number: ");
		int accNo = scan.nextInt();
		if (vali.isAccountNumberValid(accNo)) {
			bankde = serv.getAccountById(accNo);
			System.out.println("Name: " + bankde.getName());
			System.out.println("Your Account Balance is: " + bankde.getAccBalance());
		}
		else {
			throw new InvalidException("Enter Valid Account Number");
		}
	}
	
	//method to deposit money
	public void deposit() throws InvalidException {
		serv = new BankService();
		bankde = new BankDetails();
		vali = new Validator();
		System.out.print("Enter your Account Number: ");
		int accNo = scan.nextInt();
		if (vali.isAccountNumberValid(accNo)) {
			bankde = serv.getAccountById(accNo);
			System.out.println("Name: " + bankde.getName());
			System.out.println("Your Account Balance is: " + bankde.getAccBalance());
			int initBal = bankde.getAccBalance();
			System.out.print("Enter the Amount you want to Deposit: ");
			int depAmt = scan.nextInt();
			if(vali.isBalanceValid(depAmt)) {
				bankde.setAccBalance(initBal + depAmt);
				serv.deposit(bankde);

				// Updating In Transaction Table
				
				transaction2.setTransactionType("Deposit");
				transaction2.setAccId(accNo);
				transaction2.setAmount(depAmt);
				serv.addTransaction(transaction2);
				bankde.setT(transaction2);
				System.out.println("Your Account Balance after Depositing: " +bankde.getAccBalance());
			}
			else {
				throw new InvalidException("Enter Valid Amount");
			}
		}
		else {
			throw new InvalidException("Enter Valid Account Number");
		}
	}
	
	//method to withdraw money
	public void withdraw() throws InvalidException {
		serv = new BankService();
		bankde = new BankDetails();
		vali = new Validator();
		System.out.print("Enter your Account number: ");
		int accNo = scan.nextInt();
		if (vali.isAccountNumberValid(accNo)) {
			bankde = serv.getAccountById(accNo);
			System.out.println(" Your Account Balance is: " + bankde.getAccBalance());
			int initBal = bankde.getAccBalance(); // initial balance
			
			System.out.print("Enter the Amount you to Withdraw: ");
			int amount = scan.nextInt();
			
			if(vali.isBalanceValid(amount) && (initBal>amount)) {
				bankde.setAccBalance(initBal - amount);
				serv.withdraw(bankde);

				// Updating In Transaction Table
				
				transaction2.setTransactionType("Withdraw");
				transaction2.setAccId(accNo);
				transaction2.setAmount(amount);
				serv.addTransaction(transaction2);
				bankde.setT(transaction2);

				bankde = serv.getAccountById(accNo);
				System.out.println("Hello " + bankde.getName());
				System.out.println("Your Remaining Account Balance after Withdraw: " +bankde.getAccBalance());
			}
			else {
				throw new InvalidException("Enter Valid Amount");
			}
		}
		else {
			throw new InvalidException("Enter Valid Account Number");
		}
	}
	
	//method to tranfer fund
	public void fundTransfer() throws InvalidException {
		serv = new BankService();
		bankde = new BankDetails();
		vali = new Validator();
		transaction1 = new TransactionDetails();
		System.out.print("Enter the Sender Account Number: ");
		int senderAccNo = scan.nextInt(); // From Account Id (Sender)
		if (vali.isAccountNumberValid(senderAccNo)) {
			bankde = serv.getAccountById(senderAccNo);
			int senderBalance = bankde.getAccBalance(); // Initial Balance
			System.out.println("Enter the amount you want to transfer");
			int amount = scan.nextInt(); // Amount to be transfered
			if(vali.isBalanceValid(amount)) {
				
				System.out.print("Enter Reciever Account Number: ");
				int recAccNo = scan.nextInt();
				
				if (vali.isAccountNumberValid(recAccNo)) {
					// Removing the Balance transfered from sender Account
					
					bankde = serv.getAccountById(senderAccNo);
					int remBalance = senderBalance - amount;
					bankde.setAccBalance(remBalance);
					serv.deposit(bankde);

					// updating the Balance recieved from Sender
					
					bankde = serv.getAccountById(recAccNo);
					int initBalance = bankde.getAccBalance();
					int updateBalance = initBalance + amount;
					bankde.setAccBalance(updateBalance);
					serv.deposit(bankde);

					// updating In transaction Table
					
					transaction1.setTransactionType("Transfered to " + recAccNo);
					transaction1.setAccId(senderAccNo);
					transaction1.setAmount(amount);
					serv.addTransaction(transaction1);
					bankde.setT(transaction1);
					int a = transaction1.getTransactionId();

					/*
					 * //Updating In transaction Table trans1.setTransactionId(a);
					 * trans1.setTransactionType("Recieved From"+fid); trans1.setAccId(tid);
					 * trans1.setAmount(fund); service.addTransaction(trans1); bank.setT(trans1);
					 * 
					 */

					bankde = serv.getAccountById(senderAccNo);
					System.out.println("Remaining balance in account " +bankde.getAccBalance());
				}
				else {
					throw new InvalidException("Enter valid Account Number");
				}
			}
			else {
				throw new InvalidException("Enter valid Amount");
			}
		}
		else {
			throw new InvalidException("Enter Valid Account Number");
		}
	}
	
	//method to print transactions
	public void printTransactions() throws InvalidException {
		serv = new BankService();
		vali = new Validator();
		System.out.print("Enter Account number: ");
		int accNo = scan.nextInt();
		if(vali.isAccountNumberValid(accNo)) {
			serv.printTransactions(accNo);
		}
		else {
			throw new InvalidException("Enter Valid Account Number");
		}
	}
	
}
