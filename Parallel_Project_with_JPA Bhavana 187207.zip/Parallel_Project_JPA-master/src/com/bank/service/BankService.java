package com.bank.service;

import com.bank.dao.BankDAO;
import com.bank.entity.BankDetails;
import com.bank.entity.TransactionDetails;

public class BankService implements BankServiceInterface {
	BankDAO bdao = new BankDAO();

	@Override
	public BankDetails getAccountById(int id) {
		BankDetails bank = bdao.getAccountById(id);
		return bank;
	}

	@Override
	public void createAccount(BankDetails bank) {
		bdao.beginTransaction();
		bdao.CreateAccount(bank);
		bdao.commitTransaction();
	}

	@Override
	public void showBalance(BankDetails bank) {
		// TODO Auto-generated method stub
	}

	@Override
	public void deposit(BankDetails bank) {
		bdao.beginTransaction();
		bdao.Deposit(bank);
		bdao.commitTransaction();
	}

	@Override
	public void withdraw(BankDetails bank) {
		bdao.beginTransaction();
		bdao.Withdraw(bank);
		bdao.commitTransaction();
	}

	@Override
	public void printTransactions(int id) {
		bdao.PrintTransactions(id);
	}

	@Override
	public void commitTransaction() {
		bdao.commitTransaction();
	}

	@Override
	public void beginTransaction() {
		bdao.beginTransaction();
	}

	public void addTransaction(TransactionDetails transaction) {
		bdao.beginTransaction();
		bdao.addTransaction(transaction);
		bdao.commitTransaction();
	}
}