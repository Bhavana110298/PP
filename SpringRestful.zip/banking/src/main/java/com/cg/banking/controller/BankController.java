package com.cg.banking.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cg.banking.exception.BankException;
import com.cg.banking.service.BankService;
import com.cg.banking.entities.BankEntity;
import com.cg.banking.entities.TransactionEntity;

@RestController
@RequestMapping("/BankApplication")
public class BankController {
	@Autowired
	BankService bankService;

	@GetMapping("/showoptions")
	public ResponseEntity<String> ShowOptions() {
		return new ResponseEntity<String>("Welcome to XYZ Bank\n\n"+
				"1. Create Account 		: 	/creatacc\n"
				+ "2. Show Details 		: 	/showdetails/{accNum}\n"
				+ "3. Show Balance		: 	/showbal/{accNum}\n"
				+ "4. Deposite Amount 	: 	/depositamt/{accNum}/{amount}\n"
				+ "5. Withdraw Amount 	: 	/withdrawamt/{accNum}/{amount}\n"
				+ "6. Fund Transafer 	: 	/fundtransfer/{accNum1}/{amount}/{accNum2}\n"
				+ "7. Mini Statement 	: 	/ministmt/{accNum}", HttpStatus.OK);
	}
	
	@RequestMapping(value="/creatacc", method= RequestMethod.POST)
	public BankEntity createAccount(@RequestBody BankEntity bankEntity) throws BankException {
		return bankService.createAccount(bankEntity);
	}
	
	@GetMapping("/showdetails/{accNum}")
	public BankEntity accountsDetails(@PathVariable Long accNum) throws BankException {
		return bankService.accountsDetails(accNum);
	}

	@GetMapping("/showbal/{accNum}")
	public ResponseEntity<String> showBalance(@PathVariable Long accNum) throws BankException {
		Double bal = bankService.showBalance(accNum);
		return new ResponseEntity<String>("Your Current Balance : " + bal , HttpStatus.OK);
	}

	@PutMapping("/depositamt/{accNum}/{amount}")
	public ResponseEntity<String> deposit(@PathVariable Long accNum, @PathVariable Double amount) throws BankException {
		Double bal = bankService.deposit(accNum, amount);
		return new ResponseEntity<String>("Amount Deposited Successfully\n"
				+ "\n\nTransaction Amount : "+amount
				+"\n\n-----------------------------------------\n"
				+ "Your Updated Balance : " +bal
				+ "\n-----------------------------------------", HttpStatus.OK);
	}

	@PutMapping("/withdrawamt/{accNum}/{amount}")
	public ResponseEntity<String> withDraw(@PathVariable Long accNum, @PathVariable Double amount) throws BankException {
		Double bal = bankService.withDraw(accNum, amount);
		return new ResponseEntity<String>("Amount Withdrawn Successfully\n"
				+ "\n\nTransaction Amount : "+amount
				+"\n\n-----------------------------------------\n"
				+ "Your Updated Balance : " +bal
				+ "\n-----------------------------------------", HttpStatus.OK);
	}

	@PutMapping("/fundtransfer/{sender}/{amount}/{reciver}")
	public ResponseEntity<String> fundTransfer(@PathVariable Long sender, @PathVariable Double amount,
			@PathVariable Long reciver) throws BankException {
		Double bal = bankService.fundTransfer(sender, amount, reciver);
		return new ResponseEntity<String>("Amount Transferred Successfully\n-----------------------------------------"
				+ "\n\nTransaction Amount : "+amount
				+ "\nTransferred to : "+reciver+"\n\n-----------------------------------------\n"
				+ "Your Updated Balance : " +bal
				+ "\n-----------------------------------------", HttpStatus.OK);
	}

	@GetMapping("/ministmt/{accNum}")
	public List<TransactionEntity> printTransaction(@PathVariable Long accNum) throws BankException {
		return bankService.printTransaction(accNum); 
	}

}

