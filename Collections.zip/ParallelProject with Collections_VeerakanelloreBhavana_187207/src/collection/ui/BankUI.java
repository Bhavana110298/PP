package collection.ui;

import java.util.Scanner;

import collection.exceptions.*;
import collection.service.BankService;
import collection.service.BankServiceImpl;

public class BankUI {

	static Scanner scan = new Scanner(System.in);

	public static void main(String[] args) throws AccountNotFoundException {

		// variables initialization and declarations

		long accNum, accNum1;
		int withdraw_amount, deposit_amount = 0, transfer_amount = 0;
		int pin;
		int amount = 0;
		int balance = 0;
		boolean result = false;
		String cont = "yes";

		BankService service = new BankServiceImpl();

		// To ask choice from users and perform operations
		while (cont.equalsIgnoreCase("yes")) {
			switch (menu()) {

			// to create an account

			case 1:

				System.out.println("Enter name:");
				String name = scan.nextLine();
				name += scan.nextLine();

				String regexUserName = "[A-Za-z\\s]+$";
				while (!name.matches(regexUserName)) {

					System.out.println("Invalid Format");
					System.out.println("Enter name:");
					name = scan.next();
				}

				System.out.println("Enter address: ");
				String add = scan.next();
				add += scan.nextLine();

				while (!add.matches(regexUserName)) {
					System.out.println("Invalid Format");
					System.out.println("Enter address: ");
					add = scan.nextLine();

				}

				System.out.println("Enter phone number:");
				String phone = scan.next();
				String phone_format = ("[6-9][0-9]{9}");

				while (!phone.matches(phone_format)) {
					while (phone.length() < 10 || phone.length() > 10) {

						System.out.println("Phone number should be of 10 digits");
						System.out.println("Enter phone number:");
						phone = scan.next();
					}
					System.out.println("Phone number should start from 6");
					System.out.println("Enter phone number:");
					phone = scan.next();
				}

				accNum = Long.parseLong(phone) - 10000;

				System.out.println("Enter Pin:");
				pin = scan.nextInt();

				while (String.valueOf(pin).length() < 4 || String.valueOf(pin).length() > 4) {

					System.out.println("Pin number should be 0f 4 digits");
					System.out.println("Enter Pin:");
					pin = scan.nextInt();
				}

				System.out.println("Enter Balance:");
				int bal = scan.nextInt();

				while (bal < 1000) {
					System.out.println("Minimum Balance should be 1000");
					System.out.println("Enter Balance:");
					bal = scan.nextInt();

				}
				try {
					result = service.createAccount(name, add, accNum, phone, pin, bal);
				} catch (AccountAlreadyExistsException e) {

					System.out.println(e);
					break;
				}

				if (result == true) {
					System.out.println("Account Created Successfully !!!");
					System.out.println("Account Number : " + accNum);

				} else {

					System.out.println("Cannot Create Account");
				}

				break;

			// to show balance in the account
			case 2:

				System.out.println("Enter account number:");
				accNum = scan.nextLong();

				try {
					balance = service.showBalance(accNum);
				} catch (AccountNotFoundException e) {
					System.out.println(e);
					break;
				}

				System.out.println("Balance :" + balance);

				break;

			// to deposit money into account

			case 3:

				System.out.println("Enter account number:");
				accNum = scan.nextLong();

				System.out.println("Enter amount to be deposited:");
				deposit_amount = scan.nextInt();

				try {
					amount = service.deposit(accNum, deposit_amount);

					balance = service.showBalance(accNum);
				}

				catch (AccountNotFoundException e) {

					System.out.println(e);
					break;
				}

				System.out.println("Amount Deposited : " + deposit_amount);
				System.out.println("Updated Balance : " + balance);

				break;

			// to withdraw money from account

			case 4:

				System.out.println("Enter account no:");
				accNum = scan.nextLong();

				System.out.println("Enter amount to withdraw:");
				withdraw_amount = scan.nextInt();

				try {
					amount = service.withdraw(accNum, withdraw_amount);
					result = service.validateBalance(accNum, withdraw_amount);
					balance = service.showBalance(accNum);

				} catch (AccountNotFoundException e) {

					System.out.println(e);
					break;

				} catch (LowBalanceException e) {

					System.out.println(e);
					break;
				}

				System.out.println("Amount Withdrawn : " + withdraw_amount);
				System.out.println("Updated Balance : " + balance);

				break;

			// to transfer fund

			case 5:

				int senders_balance = 0;
				int recievers_balance = 0;

				System.out.println("Enter account number:");
				accNum = scan.nextLong();

				System.out.println("Enter account to which you want to transfer fund:");
				accNum1 = scan.nextLong();

				System.out.println("Enter amount to transfer:");
				transfer_amount = scan.nextInt();

				try {
					result = service.validateBalance(accNum, transfer_amount);
					result = service.transferfund(accNum, accNum1, transfer_amount);

					senders_balance = service.showBalance(accNum);
					recievers_balance = service.showBalance(accNum1);

				} catch (AccountNotFoundException e) {

					System.out.println(e);
					break;
				} catch (LowBalanceException e) {
					System.out.println(e);
					break;
				}

				System.out.println("Amount transferred Successfully");
				System.out.println("Updated balance for Account " + accNum + " : " + senders_balance);
				System.out.println("Updated balance for Account " + accNum1 + " : " + recievers_balance);

				break;

			// to show transactions
			case 6:

				String s = null;
				System.out.println("Enter account number");
				accNum = scan.nextLong();
				System.out.println("Enter pin");
				pin = scan.nextInt();
				try {
					s = service.setTrans(accNum);
					System.out.println(s);
				} catch (AccountNotFoundException e) {
					System.out.println(e);
				}
				break;
				// to exit
			case 7:
				System.out.println("Thankyou");
				System.exit(0);
				cont = "no";
				break;
			default:
				System.out.println("Please Enter choice between 1 - 7 ");
				menu();

			}
		}

	}

	// to display menu options
	public static int menu() {

		System.out.println("------------Welcome to Capgemini Bank----------");
		System.out.println("Press 1 to Create Account");
		System.out.println("Press 2 to Show Balance");
		System.out.println("Press 3 to Deposit");
		System.out.println("Press 4 to Withdraw");
		System.out.println("Press 5 to Transer Fund");
		System.out.println("Press 6 to Print Transcations");
		System.out.println("Press 7 to Exit");

		System.out.println("Enter Choice");
		int choice = scan.nextInt();

		String s = Integer.toString(choice);
		String pattern = ("[0-7]{1}");
		while (!s.matches(pattern)) {
			System.out.println("Invalid Chice");
			System.out.println("Enter Choice");
			choice = scan.nextInt();
		}
		return choice;
	}

}
