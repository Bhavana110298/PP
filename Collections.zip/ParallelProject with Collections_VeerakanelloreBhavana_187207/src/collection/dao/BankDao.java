package collection.dao;

import collection.bean.BankBean;

//interface 
public interface BankDao {

	public BankBean checkAccount(long accNum);

	public void setData(long accNum, BankBean bean);

}
